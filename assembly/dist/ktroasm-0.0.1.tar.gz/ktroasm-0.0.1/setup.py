from setuptools import setup, find_packages

setup(
  name='ktroasm',
  version='0.0.1',
  packages=find_packages(),
  entry_points={
    'console_scripts': [
      'ktroasm=ktroasm.ktroasm:main'
    ]
  },
  install_requires=[
      'lark',
      # other dependencies...
  ]
)