from setuptools import setup, find_packages

setup(
  name='ktroasm',
  version='0.0.2',
  packages=find_packages(),
  entry_points={
    'console_scripts': [
      'ktroasm=ktro_asm.ktroasm:main'
    ]
  },
  install_requires=[
      'lark',
      # other dependencies...
  ]
)